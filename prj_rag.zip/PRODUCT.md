# 产品功能设计

## 角色定义

| 角色 | 权限 | 典型用户 |
|------|------|---------|
| **Admin** (管理员) | 全局管理 | IT/HR/部门主管 |
| **Editor** (编辑者) | 指定KB内上传、编辑文档 | 内容维护人员 |
| **Viewer** (查看者) | 指定KB内提问、搜索 | 普通员工 |

## 功能清单

### 知识库管理

| 功能 | Admin | Editor | Viewer | 说明 |
|------|-------|--------|--------|------|
| 创建/编辑/删除知识库 | ✓ | — | — | 名称、描述、Embedding模型选择 |
| 分类管理 | ✓ | ✓ | — | 二级分类树 |
| 标签管理 | ✓ | ✓ | — | 自由标签，按KB隔离 |
| KB权限分配 | ✓ | — | — | 按用户授予 读/写/管理 |
| 查看KB列表 | ✓ | ✓ | ✓ | 仅看到有权限的知识库 |

### 文档管理

| 功能 | Admin | Editor | Viewer | 说明 |
|------|-------|--------|--------|------|
| 上传文档 | ✓ | ✓ | — | 拖拽批量上传，自动解析索引。同名文档校验拦截，提示使用版本更新 |
| 版本更新 | ✓ | ✓(仅自己上传) | — | 就绪文档可上传新版（同扩展名），自动清旧索引 + version+1 + 重新入库 |
| 文档列表 | ✓ | ✓ | ✓ | 按状态/分类/标签筛选，显示版本号 |
| 文档预览 | ✓ | ✓ | ✓ | 仅就绪文档可预览，详见下方预览规则 |
| 文档权限 | ✓ | ✓(仅自己上传) | — | 文档级 ACL，单独屏蔽 |
| 删除/重索引 | ✓ | ✓(仅自己上传) | — | 删除同步清理 Milvus + BM25 + SQLite（CASCADE） |

#### 文档预览规则

仅 `status === "ready"` 的文档可预览。预览为 Web 内弹窗渲染，不触发文件下载。

| 条件 | 行为 |
|------|------|
| 文件 ≥ 50MB | 隐藏预览按钮，不允许预览 |
| 文件 < 50MB | 显示预览按钮，弹窗内渲染 |
| 文件已丢失（磁盘不存在） | 后端返回 404 |

**按文件类型的预览方式：**

| 文件类型 | 预览方式 | 说明 |
|----------|----------|------|
| PDF (`application/pdf`) | 新窗口打开 | `window.open(url)`，浏览器原生 PDF 查看器渲染 |
| 图片 (`image/*`) | 新窗口打开 | `window.open(url)`，浏览器原生图片查看 |
| 文本类 (MD/HTML/TXT/CSV) | 弹窗内 `<pre>` 文本渲染 | 后端读取原文件内容返回 |
| Office 文档 (DOCX/XLSX/PPTX) | 弹窗内 `<pre>` 文本渲染 | 后端通过 parser 提取文本内容后返回 |

**后端接口：**

| 端点 | 用途 | 认证 |
|------|------|------|
| `GET /kbs/{kb_id}/documents/{doc_id}/file` | 返回原始文件（PDF/图片由浏览器原生渲染） | `?token=` query 参数 |
| `GET /kbs/{kb_id}/documents/{doc_id}/text` | 返回文档解析后的纯文本（MD/HTML/Office 文档） | `?token=` query 参数 |

两个接口均通过 URL query `?token=` 认证（新窗口/iframe 打开无法设置 HTTP Header）。

### 智能问答

| 功能 | Admin | Editor | Viewer | 说明 |
|------|-------|--------|--------|------|
| 新建对话 | ✓ | ✓ | ✓ | 创建空白对话 |
| 多轮对话 | ✓ | ✓ | ✓ | 上下文记忆，持续追问 |
| 知识库范围选择 | ✓ | ✓ | ✓ | 勾选检索哪些 KB |
| 模型切换 | ✓ | ✓ | ✓ | GPT-4o / Claude / Qwen / DeepSeek 等 |
| 流式输出 | ✓ | ✓ | ✓ | SSE 实时打字效果 |
| 引用溯源 | ✓ | ✓ | ✓ | 内联标注 [来源N]，点击弹窗展示完整元数据 |
| 引用元数据 | ✓ | ✓ | ✓ | 每条引用展示：归属知识库、文档标题、页码、相关度评分、原文片段 |
| 对话历史 | ✓ | ✓ | ✓ | 列表、搜索、继续对话；历史消息保留引用可回溯 |

### 引用溯源详情

点击 AI 回答中的 `#N` 来源标记，弹出详情面板，展示以下元数据：

| 字段 | 说明 | 来源 |
|------|------|------|
| 来源编号 | 回答中 [来源N] 对应的序号 | 检索排序 |
| 知识库名称 | 该文档所属的知识库 | `knowledge_bases.name` |
| 文档标题 | 源文档文件名或标题 | `documents.title` |
| 页码 | 引用内容所在的原文页码 | `document_chunks.page_start` |
| 相关度评分 | 检索相关性百分比 | RRF 融合分数 |
| 原文片段 | 匹配到的文本内容（300字） | chunk 原文截取 |

数据链路：`parser 解析页码` → `chunker 逐页分块` → `pipeline 存入 document_chunks.page_start` → `vector/BM25 索引 chunk_id` → `qa_service 检索后回查 documents + knowledge_bases + document_chunks 补全元数据` → `前端弹窗展示`

### 搜索

| 功能 | Admin | Editor | Viewer | 说明 |
|------|-------|--------|--------|------|
| 全文搜索 | ✓ | ✓ | ✓ | 关键词搜索，返回相关片段 |
| 结果预览 | ✓ | ✓ | ✓ | 高亮匹配词，关联源文档 |

### 系统管理

| 功能 | Admin | 说明 |
|------|-------|------|
| 用户管理 | ✓ | 创建、禁用、角色分配 |
| 系统状态 | ✓ | 文档数、索引大小、存储用量 |
| 操作日志 | ✓ | 查询/上传操作审计 |

## 权限模型

```
                 ┌─────────┐
                 │  Admin  │  全系统权限
                 └────┬────┘
                      │ 创建KB、管理用户
          ┌───────────┼───────────┐
          ▼           ▼           ▼
      ┌───────┐  ┌───────┐  ┌───────┐
      │ KB-A  │  │ KB-B  │  │ KB-C  │
      │ Editor │  │ Viewer │  │ 无权限 │
      ├───────┤  ├───────┤  └───────┘
      │张三 读写│  │张三 只读│
      │王五 只读│  │王五 读写│
      └───┬───┘  └───┬───┘
          │          │
      文档级 ACL 进一步细化：
      "薪资政策.docx" 仅张三可见
```

1. **KB 级权限**：用户对知识库有 管理/写/读/无 四级
2. **文档级权限**：在 KB 权限基础上更细粒度控制，某篇文档可单独对指定用户屏蔽，检索时 ACL Filter 拦截
3. **权限校验点**：
   - KB 列表展示时过滤无权限的 KB
   - 检索时 ACL Filter 过滤无权限的文档
   - 上传/删除文档时校验 KB 写权限

## 用户流程

### Admin 首次使用流程

```
登录 → 创建用户账号 → 创建知识库 → 给用户分配KB权限
  → 上传文档 → 等待索引就绪 → 查看系统状态确认正常
  → 后续：监控系统、新增文档、管理权限
```

### Viewer 日常使用流程（主路径，90% 场景）

```
登录 → 看到知识库列表 → 新建对话 → 选择检索范围(KB勾选)
  → 输入问题 → 收到流式回答 + 引用标注 → 点击引用查看来源元数据
  → 追问（多轮） → 满意后关闭
  → 不满意 → 全文搜索 → 浏览片段 → 找到后关闭
```

### Editor 文档维护流程

```
登录 → 进入知识库 → 上传新文档 → 等待索引完成（状态轮询）
  → 设置分类/标签 → 如需限制可见范围，设置文档权限
  → 后续：过期文档删除、内容更新重索引
```

### 检索响应路径（后台处理）

```
用户提问
  │
  ├─ 1. 对话历史加载 ─── 从 SQLite 加载最近 10 轮对话（20 条消息）
  │    作用：为多轮追问提供上下文，让 LLM 理解"它"指代什么
  │    实现：select messages where conversation_id order by created_at desc limit 20
  │
  ├─ 2. Query Rewriter ─── 有历史时，调 LLM 将口语追问改写为独立检索查询
  │    作用："那违约的呢？" → "违约责任的承担方式有哪些？"
  │    实现：取最近 6 条历史拼 prompt，调 LLM 做改写（temperature=0.1, max_tokens=200）
  │    开销：额外 1 次 LLM 调用，约 1-2s 延迟
  │
  ├─ 3. 查询缓存检查 ─── 内存 LRU 缓存（100 条，TTL 10 分钟）
  │    作用：相同问题 + 相同 KB 范围直接返回缓存结果，跳过全部检索
  │    实现：MD5(question + sorted_kb_ids) 精确匹配
  │    局限：字面差异（多一个空格）即不命中，无历史时才能用
  │
  ├─ 4a. 向量检索 ─── Milvus COSINE 相似度搜索
  │    作用：语义匹配，找到"意思相近"的文档片段（如搜"合同无效"也能命中"合同未生效"）
  │    实现：query 向量化（智谱 Embedding-3）→ Milvus.search(top_k=50)
  │    参数：1024 维向量，COSINE 距离
  │
  ├─ 4b. BM25 关键词检索 ─── 内存倒排索引
  │    作用：精确关键词匹配，弥补向量检索对专有名词、数字、法条的召回盲区
  │    实现：rank-bm25 纯 Python 实现，启动时从 document_chunks 表全量构建，增量更新
  │    参数：top_k=50，jieba 中文分词
  │
  ├─ 4c. RRF 融合 ─── Reciprocal Rank Fusion（k=60）
  │    作用：合并向量和 BM25 两组排序结果，自动调和两种分数的量纲差异
  │    实现：RRF_score(chunk) = Σ 1/(k + rank_i + 1)，对每个来源累加
  │    现状：融合后直接截断到 top_k=5 给下游 —— 过早，浪费召回多样性
  │
  ├─ 4d. ACL 过滤 ─── 按用户可见文档白名单过滤
  │    作用：移除用户无权查看的文档片段（文档级权限控制）
  │    实现：查 user_kb_permissions + document_permissions 表，构建可见 doc_id 集合
  │
  ├─ 4e. Reranker（❌ 已禁用）── 智谱 bge-reranker-large 精排
  │    作用：对 RRF 候选做精细语义排序，区分"真正相关"和"只是看起来像"的片段
  │    实现：代码已在 hybrid_retriever.py 中完整接入 API，但调用时 use_reranker=False
  │    影响：精排环节缺失，LLM 可能拿到不精准的上下文
  │
  ├─ 5. 元数据回查 ─── 补全 KB 名、文档标题、页码
  │    作用：从 search results 的 document_id 和 chunk_id 反查业务表，拼装完整引用信息
  │    实现：批量查 documents(id, title)，knowledge_bases(id, name)，document_chunks(doc_id, chunk_index, page_start)
  │
  ├─ 6. Prompt 拼装 ─── 系统指令 + 对话历史 + 检索上下文 + 用户问题
  │    作用：构建 LLM 的输入，限定只依据提供的文档回答，要求标注来源
  │    模板：你是一个企业知识库助手。仅根据以下提供的文档内容回答问题...
  │
  ├─ 7. LLM 生成 ─── 调用配置的模型（当前 deepseek-v4-pro）
  │    流式：SSE token 逐个推送前端，实时打字效果
  │    非流式：等待完整响应后返回，可缓存
  │    参数：temperature=0.3, max_tokens=1024
  │
  └─ 8. 结果持久化 ─── 保存消息 + 引用关系到 SQLite
       作用：支持对话历史和引用回溯
       实现：Message 表存问答内容，MessageCitation 表存引用关系（含页码）
```


### 文档摄入流程

```
用户上传文件
  → 1. 校验（格式、大小、KB权限）
  → 2. 存本地 ./data/files/
  → 3. BackgroundTask：Parser（按MIME分发，逐页提取文本与页码）
  → 4. Chunk（1024字符 + 128重叠，jieba中文分句，继承页码）
  → 5. Embed（智谱 Embedding-3 API，32条/批，含重试）
  → 6. 双写索引（Milvus Lite + BM25 内存索引）
  → 7. 更新文档状态为 ready
```

### 文档分块策略

#### 总流程图

```text
                        用户上传文档
                             |
                             v
              +-------------------------------+
              |    MIME 类型识别(扩展名)      |
              |   .pdf / .docx / .md / .txt   |
              +-------------------------------+
                             |
            +----------------+----------------+
            |                |                |
            v                v                v
      +----------+    +----------+    +----------+
      |PDFParser |    |DocxParser|    | MD/TXT   |
      |          |    |          |    | Parser   |
      +-----+----+    +-----+----+    +-----+----+
            |               |               |
            v               v               v
     +-------------+  +-----------+  +-----------+
     |采样5页判断类型|  |识别Heading |  |识别#标题   |
     |p1/5/10/20/50|  |样式1/2/3  |  |(MD only)  |
     +--+-------+---+  +-----+-----+  +-----+-----+
        |       |             |               |
     >=50字符 全部<50         |               |
        |       |             |               |
        v       v             v               v
    文本型   扫描件     全文合并注入     全文合并注入
   pdfplumber 逐页OCR   [章>节]路径     [章>节]路径
   逐页提取   (百度)    1个ParsedPage    1个ParsedPage
        |       |             |               |
        +-------+-------------+---------------+
                        |
             N个 ParsedPage(page_number, text)
                        |
                        v
              +---------------------+
              |      Chunker        |
              |  chunk_text(text,    |
              |   page_number,       |
              |   chunk_size=500,    |
              |   overlap=60,        |
              |   file_type)         |
              +----------+----------+
                         |
                         v
              +---------------------+
              |  原子保护:表格/列表  |
              |  正则识别,包裹防切   |
              +----------+----------+
                         |
                         v
              +---------------------+
              |  检测章节标记?       |
              |  [章>节]/#/第X章/条  |
              +------+------+-------+
                     |YES   |NO
                     v      |
              +---------+   |
              |结构分块  |   |
              |按标题切分|   |
              |超长递归字符|  |
              |携带章节路径|  |
              +----+----+   |
                   |        |
                   |   +----+-----------+
                   |   |>2048字符+>=10句?|
                   |   +----+------+----+
                   |       YES     NO
                   |        |       |
                   |        v       v
                   |   +--------+ +----------+
                   |   |语义分块 | |递归字符   |
                   |   |Embed句子| |分块(兜底)  |
                   |   |余弦相似度| |500/60     |
                   |   |percentile| |按段落->句子 |
                   |   |10%阈值切| |->字符优先   |
                   |   +---+----+ +-----+-----+
                   |       |            |
                   +-------+------------+
                           |
                           v
                list[Chunk] (text, page, section_path, content_type)
                           |
                           v
              +-------------------------+
              |      Pipeline 入库       |
              |  32条/批 Embed->写入      |
              +----------+--------------+
                         |
            +------------+------------+
            |            |            |
            v            v            v
       +--------+  +---------+  +----------+
       | Milvus |  |  BM25   |  | SQLite   |
       |向量索引|  |关键词索引|  |document_ |
       |COSINE  |  |rank-bm25|  |chunks表  |
       +--------+  +---------+  +----------+
```

#### 各节点说明

| 节点 | 作用 | 输入 | 输出 | 关键参数 |
|------|------|------|------|---------|
| MIME识别 | 扩展名路由到对应Parser | 原始文件 | Parser实例 | .pdf/.docx/.md/.txt |
| PDFParser | 提取PDF文本,扫描件走OCR | PDF文件 | list[ParsedPage] | -- |
| PDF采样预判 | 避免对文本型PDF逐页试OCR | PDF文件 | is_scanned(bool) | 采样页:[1,5,10,20,50], 阈值:50字符 |
| 百度OCR | 扫描件页面文字识别 | PNG(bytes) | 识别文本 | DPI:200, lang:CHN_ENG |
| DocxParser | 提取DOCX文本+标题结构 | DOCX文件 | 1个ParsedPage(带[章>节]路径) | Heading样式1/2/3 |
| MD Parser | 提取MD文本+标题结构 | MD文件 | 1个ParsedPage(带#标题路径) | # 标题行 |
| TXT Parser | 纯文本读取 | TXT文件 | 1个ParsedPage | UTF-8 |
| 原子保护 | 表格/列表不跨chunk切碎 | 原始文本 | 包裹后文本 | 正则:表格行 ^\\|.+\\|$ 列表 ^[-*+\\d] |
| 章节检测 | 判断是否走结构分块 | 文本 | bool | 标记: [章>节] / # / 第X章/条 |
| 结构分块 | 按标题边界切分,携带章节路径 | 文本+标题标记 | list[Chunk] | 超长内部递归 chunk_size=500 |
| 语义分块 | 按话题相似度切分 | 句子列表 | list[Chunk] | >2048字符, >=10句, percentile=10% |
| 递归字符分块 | 兜底,段落->句子->字符优先级切 | 文本 | list[Chunk] | chunk_size=500, overlap=60 |
| Pipeline入库 | 批量Embed->写向量库+DB | list[Chunk] | -- | 32条/批 |

#### Chunk元数据字段

| 字段 | 说明 | 来源 | 有结构(DOCX/MD) | 无结构(PDF/TXT) |
|------|------|------|:--:|:--:|
| text | 分块文本内容 | chunker | Y | Y |
| page_start | 起始页码 | Parser | Y(DOCX=1) | Y |
| page_end | 结束页码 | Parser | Y | Y |
| section_path | 章节路径 | 结构分块 | Y [章>节] | N |
| content_type | 内容类型 | 结构分块 | Y(prose/clause) | Y(prose) |
| token_count | 字符数 | chunker | Y | Y |

> PDF/TXT缺section_path是已知局限：pdfplumber提取纯文本不保留标题层级；TXT本身无结构标记。

#### 关键参数汇总

| 参数 | 值 | 用途 |
|------|-----|------|
| chunk_size | 500字符 | 通用prose,递归分块和结构分块超长回退 |
| overlap | 60字符(12%) | 相邻chunk重叠 |
| OCR阈值 | 50字符/页 | 判断单页是否扫描件 |
| OCR采样页 | [1,5,10,20,50] | 预判整个PDF类型 |
| OCR DPI | 200 | PyMuPDF渲染分辨率 |
| Embed批大小 | 32 | 智谱Embedding-3限制64,留余量 |
| 语义最低字符 | 2048 | 短文本不值得调Embed API |
| 语义最低句子 | 10 | 句子太少无法计算相似度 |
| 语义percentile | 10% | 最低10%相似度处切分 |
| 硬上限 | chunk_size*1.5 | 单组超过强制回退字符切分 |

## 数据库设计
## 数据库设计

数据库：SQLite（单文件 `data/rag.db`），ORM：SQLAlchemy 2.0 async，引擎：aiosqlite。

### ER 关系总览

```
 users ──┬── knowledge_bases ──┬── documents ──┬── document_chunks
  │      │    │                │    │            │
  │      │    ├── categories   │    ├── document_permissions
  │      │    ├── tags         │    ├── document_categories
  │      │    └── user_kb_permissions │── document_tags
  │      │
  │      └── conversations ─── messages ─── message_citations
  │                                        │
  └────────────────────────────────────────┘
```

### 表结构

#### `users` — 用户

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | 用户唯一标识 |
| username | VARCHAR(64) | UNIQUE, NOT NULL | 登录名 |
| email | VARCHAR(255) | UNIQUE, NOT NULL | 邮箱 |
| hashed_password | VARCHAR(255) | NOT NULL | bcrypt 哈希 |
| full_name | VARCHAR(128) | NULL | 显示名称 |
| role | VARCHAR(32) | DEFAULT 'viewer' | admin / editor / viewer |
| is_active | BOOLEAN | DEFAULT TRUE | 是否启用 |
| created_at | DATETIME | DEFAULT NOW | 创建时间 |
| updated_at | DATETIME | ON UPDATE NOW | 更新时间 |

#### `knowledge_bases` — 知识库

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | KB 唯一标识 |
| name | VARCHAR(255) | NOT NULL | KB 名称 |
| description | TEXT | NULL | KB 描述 |
| created_by | VARCHAR(36) | FK → users.id | 创建者 |
| is_public | BOOLEAN | DEFAULT FALSE | 是否公开（暂未使用） |
| embedding_model | VARCHAR(128) | DEFAULT 'zhipu-embedding-3' | 关联的 Embedding 模型 |
| chunk_size | INT | DEFAULT 1024 | 分块大小 |
| chunk_overlap | INT | DEFAULT 128 | 分块重叠 |
| created_at | DATETIME | DEFAULT NOW | 创建时间 |
| updated_at | DATETIME | ON UPDATE NOW | 更新时间 |

#### `documents` — 文档

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | 文档唯一标识 |
| kb_id | VARCHAR(36) | FK → knowledge_bases.id, CASCADE | 所属知识库 |
| title | VARCHAR(512) | NOT NULL | 文档标题（上传文件名） |
| file_type | VARCHAR(32) | NOT NULL | MIME 类型（如 application/pdf） |
| file_path | VARCHAR(1024) | NOT NULL | 本地存储路径 |
| file_size_bytes | BIGINT | NULL | 文件大小（字节） |
| page_count | INT | NULL | 总页数（解析后填入） |
| status | VARCHAR(32) | DEFAULT 'pending' | pending → parsing → indexing → ready / error |
| error_message | TEXT | NULL | 失败原因 |
| hash_md5 | VARCHAR(32) | NULL | 文件 MD5（已存储但未用于去重） |
| uploaded_by | VARCHAR(36) | FK → users.id | 上传者 |
| created_at | DATETIME | DEFAULT NOW | 上传时间 |
| updated_at | DATETIME | ON UPDATE NOW | 最后更新时间 |

#### `document_chunks` — 文档分块（检索最小单元）

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | Chunk 唯一标识 |
| document_id | VARCHAR(36) | FK → documents.id, CASCADE | 所属文档 |
| chunk_index | INT | NOT NULL | 在文档内的序号（从 1 开始） |
| chunk_text | TEXT | NOT NULL | 分块文本内容 |
| milvus_id | BIGINT | NULL | Milvus 自增主键（向量检索回查用） |
| page_start | INT | NULL | 起始页码 |
| page_end | INT | NULL | 结束页码 |
| token_count | INT | NULL | 字符数（近似 token） |
| created_at | DATETIME | DEFAULT NOW | 创建时间 |

> Milvus 中对应 Collection 存储：chunk_id（格式 `{document_id}_{chunk_index}`）、kb_id、document_id、chunk_text、vector(1024d)。

#### `conversations` — 对话

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | 对话唯一标识 |
| user_id | VARCHAR(36) | FK → users.id | 所属用户 |
| kb_id | VARCHAR(36) | FK → knowledge_bases.id, SET NULL | 关联知识库（可选） |
| title | VARCHAR(512) | NULL | 对话标题（取首个问题前 50 字） |
| model_name | VARCHAR(128) | DEFAULT 'deepseek-v4-pro' | 使用的 LLM 模型 |
| created_at | DATETIME | DEFAULT NOW | 创建时间 |
| updated_at | DATETIME | ON UPDATE NOW | 最后活跃时间 |

#### `messages` — 消息

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | 消息唯一标识 |
| conversation_id | VARCHAR(36) | FK → conversations.id, CASCADE | 所属对话 |
| role | VARCHAR(16) | NOT NULL | 'user' 或 'assistant' |
| content | TEXT | NOT NULL | 消息正文 |
| token_count | INT | NULL | token 数估计 |
| created_at | DATETIME | DEFAULT NOW | 发送时间 |

#### `message_citations` — 消息引用

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | 引用记录唯一标识 |
| message_id | VARCHAR(36) | FK → messages.id, CASCADE | 所属 AI 回答 |
| chunk_id | VARCHAR(36) | FK → document_chunks.id | 引用的 chunk |
| document_id | VARCHAR(36) | FK → documents.id | 引用的文档 |
| relevance_score | FLOAT | NULL | 检索相关度分数（RRF 融合值） |
| snippet | TEXT | NULL | 引用片段原文 |
| page_number | INT | NULL | 页码 |
| created_at | DATETIME | DEFAULT NOW | 创建时间 |

#### `user_kb_permissions` — KB 级权限

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | |
| user_id | VARCHAR(36) | FK → users.id, CASCADE | 用户 |
| kb_id | VARCHAR(36) | FK → knowledge_bases.id, CASCADE | 知识库 |
| permission | VARCHAR(16) | DEFAULT 'read' | read / write / admin |
| granted_by | VARCHAR(36) | FK → users.id, NULL | 授权人 |
| created_at | DATETIME | DEFAULT NOW | |
| | | UNIQUE(user_id, kb_id) | |

#### `document_permissions` — 文档级 ACL（访问控制列表）

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | |
| document_id | VARCHAR(36) | FK → documents.id, CASCADE | 文档 |
| user_id | VARCHAR(36) | FK → users.id, CASCADE | 用户（仅指定用户可读，白名单模式） |
| permission | VARCHAR(16) | DEFAULT 'read' | |
| created_at | DATETIME | DEFAULT NOW | |
| | | UNIQUE(document_id, user_id) | |

#### `categories` — 分类（二级树）

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | |
| kb_id | VARCHAR(36) | FK → knowledge_bases.id, CASCADE | 所属 KB |
| name | VARCHAR(128) | NOT NULL | 分类名称 |
| parent_id | VARCHAR(36) | FK → categories.id, NULL | 父分类（NULL = 一级） |
| | | UNIQUE(kb_id, name) | |

#### `tags` — 标签

| 列 | 类型 | 约束 | 说明 |
|----|------|------|------|
| id | VARCHAR(36) | PK, UUID | |
| kb_id | VARCHAR(36) | FK → knowledge_bases.id, CASCADE | 所属 KB |
| name | VARCHAR(64) | NOT NULL | 标签名 |
| | | UNIQUE(kb_id, name) | |

#### `document_categories` — 文档-分类关联

| 列 | 类型 | 约束 |
|----|------|------|
| document_id | VARCHAR(36) | PK, FK → documents.id, CASCADE |
| category_id | VARCHAR(36) | PK, FK → categories.id, CASCADE |

#### `document_tags` — 文档-标签关联

| 列 | 类型 | 约束 |
|----|------|------|
| document_id | VARCHAR(36) | PK, FK → documents.id, CASCADE |
| tag_id | VARCHAR(36) | PK, FK → tags.id, CASCADE |

### 外键关系速查

```
users.id ──→ knowledge_bases.created_by
users.id ──→ documents.uploaded_by
users.id ──→ conversations.user_id
users.id ──→ user_kb_permissions.user_id
users.id ──→ user_kb_permissions.granted_by
users.id ──→ document_permissions.user_id

knowledge_bases.id ──→ documents.kb_id (CASCADE)
knowledge_bases.id ──→ conversations.kb_id (SET NULL)
knowledge_bases.id ──→ user_kb_permissions.kb_id (CASCADE)
knowledge_bases.id ──→ categories.kb_id (CASCADE)
knowledge_bases.id ──→ tags.kb_id (CASCADE)

documents.id ──→ document_chunks.document_id (CASCADE)
documents.id ──→ message_citations.document_id
documents.id ──→ document_permissions.document_id (CASCADE)
documents.id ──→ document_categories.document_id (CASCADE)
documents.id ──→ document_tags.document_id (CASCADE)

conversations.id ──→ messages.conversation_id (CASCADE)
messages.id ──→ message_citations.message_id (CASCADE)

categories.id ──→ categories.parent_id
categories.id ──→ document_categories.category_id (CASCADE)
tags.id ──→ document_tags.tag_id (CASCADE)
```

### 索引策略

| 表 | 索引 | 类型 |
|----|------|------|
| users | username, email | UNIQUE（自动） |
| user_kb_permissions | (user_id, kb_id) | UNIQUE 复合 |
| document_permissions | (document_id, user_id) | UNIQUE 复合 |
| categories | (kb_id, name) | UNIQUE 复合 |
| tags | (kb_id, name) | UNIQUE 复合 |
| documents | kb_id | 隐式（FK） |
| document_chunks | document_id, chunk_index | 查询热点，组合查询频繁 |
| messages | conversation_id, created_at | 查询热点 |
| message_citations | message_id | 隐式（FK） |

> 当前未显式创建额外索引。SQLite 自动为所有主键和 UNIQUE 约束创建索引。document_chunks (document_id, chunk_index) 的查询频繁但无复合索引——目前数据量小不影响，数据量大时需补充。

## 待办事项

### ✅ 已完成

| 条目 | 说明 |
|------|------|
| 启用 Reranker | 智谱 rerank API，管线：Vector+BM25 → RRF → top-20 → Reranker → top-5 |
| RRF 截断优化 | 随 Reranker 启用完成 |
| 删除同步清理 Milvus | BM25 + Milvus + SQLite CASCADE 三路清理 |
| 重索引先清后建 | 先清旧数据再重建 |
| 文档版本管理 | `version` + `POST /update` + 同名上传拦截 |
| Reranker 分数精度 | 8 位小数显示 |
| 引用元数据 | KB名、文档标题、页码、相关度 |
| 元数据回查合并 | 页码查询从 N+1 改为一次批量 SQL |
| 结构感知切分 | DOCX/MD/HTML 解析器保留标题层级，chunk 带 `【章 > 节】` 路径 |
| Query Rewriter 轻量化 | 取消额外 LLM 调用，改为拼接最近用户消息 |
| 语义切分 | percentile 阈值法（企业级标准），<20句走回退，长文本 Embed 句子相似度在最低 10% 处分界 |
| 多粒度索引 / 上下文扩展 | 检索命中后自动携带前后各 1 chunk 扩展上下文给 LLM |
| 表格/列表原子保护 | chunker 预处理器识别 markdown 表格行和列表项，包裹为原子单元防切碎 |

### 🔴 P0 — 无

### 🟡 P1 — 无

### 🟢 P2 — 无

### 🟢 P3 — 无

> 语义缓存：经评估不实施。Embedding 相似度匹配需先调 Embedding API 才能查缓存，反而增加延迟。当前 MD5 精确匹配更快。
